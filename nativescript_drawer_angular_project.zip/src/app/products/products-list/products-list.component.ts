import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { RouterExtensions } from '@nativescript/angular';
import { RadSideDrawer } from 'nativescript-ui-sidedrawer';
import { Application } from '@nativescript/core';
import { ProductService } from '../../core/services/product.service';
import { Product } from '../../core/models/product.model';

@Component({
  selector: 'ns-products-list',
  templateUrl: './products-list.component.tns.html',
  styleUrls: ['./products-list.component.css']
})
export class ProductsListComponent implements OnInit {
  products$!: Observable<Product[]>;

  constructor(
    private productService: ProductService,
    private routerExtensions: RouterExtensions
  ) {}

  ngOnInit(): void {
    this.products$ = this.productService.getProducts();
  }

  onDrawerButtonTap(): void {
    const sideDrawer = <RadSideDrawer>Application.getRootView();
    if (sideDrawer) {
      sideDrawer.showDrawer();
    }
  }

  onSelectProduct(productId: number): void {
    this.routerExtensions.navigate(['/products/detail', productId], {
      transition: {
        name: 'slide',
        duration: 250,
        curve: 'easeInOut'
      }
    });
  }
}
