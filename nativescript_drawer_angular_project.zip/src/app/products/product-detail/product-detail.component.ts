import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RouterExtensions } from '@nativescript/angular';
import { isAndroid, isIOS, Device } from '@nativescript/core';
import { ProductService } from '../../core/services/product.service';
import { Product } from '../../core/models/product.model';

@Component({
  selector: 'ns-product-detail',
  templateUrl: './product-detail.component.tns.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  product?: Product;

  platformName: string = 'Multiplatform Core';
  hasPlatformDiscount: boolean = false;

  // [REQ 10] Variables asignadas cuando se está en Android solamente
  androidExclusivePromoCode: string = '';
  androidDiscountPercentage: number = 0;
  androidOsSummary: string = '';
  androidBannerColor: string = '';

  constructor(
    private route: ActivatedRoute,
    private routerExtensions: RouterExtensions,
    private productService: ProductService
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.params.id);
    this.productService.getProductById(id).subscribe(item => {
      this.product = item;
    });

    // [REQ 10] Asignación condicional exclusiva para Android
    if (isAndroid) {
      this.androidExclusivePromoCode = 'DROID-SPECIAL-2026';
      this.androidDiscountPercentage = 25;
      this.androidBannerColor = '#2E7D32';
      this.androidOsSummary = `Dispositivo Android certificado (SDK ${Device.sdkVersion}, Modelo: ${Device.model})`;
      this.platformName = 'Android Native Runtime';
      this.hasPlatformDiscount = true;
    } else if (isIOS) {
      this.platformName = 'iOS Apple Runtime';
    }
  }

  onBack(): void {
    this.routerExtensions.back();
  }
}
