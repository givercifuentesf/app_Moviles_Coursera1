import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Product } from '../models/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private productsSubject = new BehaviorSubject<Product[]>([
    {
      id: 1,
      name: 'Auriculares Inalámbricos Pro',
      category: 'Audio',
      price: 129.99,
      description: 'Cancelación activa de ruido, audio espacial y 30 horas de autonomía continua.',
      imageUrl: 'res://ic_custom_products',
      inStock: true,
      rating: 4.8
    },
    {
      id: 2,
      name: 'Smartwatch Fitness Tracker',
      category: 'Wearables',
      price: 89.50,
      description: 'Monitor de ritmo cardíaco, GPS integrado y resistencia al agua 5 ATM.',
      imageUrl: 'res://ic_custom_products',
      inStock: true,
      rating: 4.5
    },
    {
      id: 3,
      name: 'Teclado Mecánico RGB',
      category: 'Periféricos',
      price: 110.00,
      description: 'Switches táctiles intercambiables en caliente y conectividad Bluetooth dual.',
      imageUrl: 'res://ic_custom_products',
      inStock: false,
      rating: 4.9
    },
    {
      id: 4,
      name: 'Power Bank 20000mAh',
      category: 'Accesorios',
      price: 45.00,
      description: 'Carga rápida USB-C Power Delivery de 65W ideal para teléfonos y portátiles.',
      imageUrl: 'res://ic_custom_products',
      inStock: true,
      rating: 4.6
    }
  ]);

  public products$: Observable<Product[]> = this.productsSubject.asObservable();

  getProducts(): Observable<Product[]> {
    return this.products$;
  }

  getProductById(id: number): Observable<Product | undefined> {
    return this.products$.pipe(
      map(items => items.find(p => p.id === id))
    );
  }

  addProduct(newProduct: Product): void {
    const current = this.productsSubject.getValue();
    this.productsSubject.next([...current, newProduct]);
  }
}
