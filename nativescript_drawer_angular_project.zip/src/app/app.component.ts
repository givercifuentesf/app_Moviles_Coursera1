import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { RouterExtensions } from '@nativescript/angular';
import { DrawerTransitionBase, SlideInOnTopTransition, RadSideDrawer } from 'nativescript-ui-sidedrawer';
import { filter } from 'rxjs/operators';
import { Application } from '@nativescript/core';

@Component({
  selector: 'ns-app',
  templateUrl: './app.component.tns.html'
})
export class AppComponent implements OnInit {
  private _activatedUrl: string = '/home';
  private _sideDrawerTransition!: DrawerTransitionBase;

  constructor(
    private router: Router,
    private routerExtensions: RouterExtensions
  ) {}

  ngOnInit(): void {
    this._sideDrawerTransition = new SlideInOnTopTransition();

    this.router.events
      .pipe(filter((event: any) => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this._activatedUrl = event.urlAfterRedirects;
      });
  }

  get sideDrawerTransition(): DrawerTransitionBase {
    return this._sideDrawerTransition;
  }

  isComponentSelected(url: string): boolean {
    return this._activatedUrl === url || this._activatedUrl.startsWith(url + '/');
  }

  onNavItemTap(navItemRoute: string): void {
    this.routerExtensions.navigate([navItemRoute], {
      transition: { name: 'fade' },
      clearHistory: true
    });

    const sideDrawer = <RadSideDrawer>Application.getRootView();
    if (sideDrawer) {
      sideDrawer.closeDrawer();
    }
  }
}
